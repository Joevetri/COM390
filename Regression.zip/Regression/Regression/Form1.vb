﻿Public Class Form1

    Dim sumy_2, sumx1_2, sumx2_2 As Double
    Dim sumx1y, sumx2y, sumx1x2 As Double
    Dim a, b1, b2 As Double

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim avgY, avgX1, avgX2 As Double
        Dim sumY, sumX1, sumX2 As Double
        Dim sumSQY, sumSQX1, sumSQX2 As Double
        Dim sumYX1, sumYX2, sumX1X2 As Double

        Dim Y = New Double() {2, 4, 4, 1, 5, 4, 7, 9, 7, 8, 5, 2, 8, 6, 10, 9, 3, 6, 7, 10}
        Dim X1 = New Double() {1, 2, 1, 1, 3, 4, 5, 5, 7, 6, 4, 3, 6, 6, 8, 9, 2, 6, 4, 4}
        Dim X2 = New Double() {3, 5, 3, 4, 6, 5, 6, 7, 8, 4, 3, 4, 6, 7, 7, 6, 6, 5, 6, 9}

        Dim N = (Y.Length)

        Dim sumY = CalcSum(Y)
        Dim avgY = CalcMean(sumY, Y.Length)

        Dim sumX1 = CalcSum(X1)
        Dim avgX1 = CalcMean(sumX1, X1.Length)

        Dim sumX2 = CalcSum(X2)
        Dim avgX2 = CalcMean(sumX2, X2.Length)

        Console.WriteLine("Sum Y = " + sumY + "  avgY = " + avgY)
        Console.WriteLine("SumX1 = " + sumX1 + "  avgX1 = " + avgX1)
        Console.WriteLine("SumX2 = " + sumX2 + "  avgX2 = " + avgX2)

        Dim sumSQY = CalcSumOfSquares(Y)
        Dim sumSQX1 = CalcSumOfSquares(X1)
        Dim sumSQX2 = CalcSumOfSquares(X2)

        Console.WriteLine("Y SQ =" + sumSQY + "  X1 SQ = " + sumSQX1 + " X2 SQ = " + sumSQX2)

        Dim sumYX1 = CalcSumOfVar(Y, X1);
        Dim sumYX2 = CalcSumOfVar(Y, X2);
        Dim sumX1X2 = CalcSumOfVar(X1, X2);

        Console.WriteLine("YX1 = " + sumYX1 + " YX2 = " + sumYX2 + " X1X2
        " + sumX1X2)

        sumy_2 = sumSQY - (Math.Pow(sumY, 2) / N)
        Console.WriteLine(" " + sumy_2)

        Dim sumx1_2 = sumSQX1 - (Math.Pow(sumX1, 2) / N)

        Console.WriteLine(" " + sumx1_2)
        Dim sumx2_2 = sumSQX2 - (Math.Pow(sumX2, 2) / N)
        Console.WriteLine(" " + sumx2_2)
        Dim sumx1y = sumYX1 - ((sumX1 * sumY) / N)
        Console.WriteLine(" " + sumx1y)
        Dim sumx2y = sumYX2 - ((sumX2 * sumY) / N)
        Console.WriteLine(" " + sumx2y)
        sumX1X2 = sumX1X2 - ((sumX1 * sumX2) / N)
        Console.WriteLine(" " + sumX1X2)
        Dim b1 = (sumx2_2 * sumx1y - sumX1X2 * sumx2y) / (sumx1_2 * sumx2_2 -
        sumX1X2 * sumX1X2)
        Console.WriteLine("b1 = " + b1)
        Dim b2 = (sumx1_2 * sumx2y - sumX1X2 * sumx1y) / (sumx1_2 * sumx2_2 -
        sumX1X2 * sumX1X2)
        Console.WriteLine("b2 = " + b2)
        Dim a = avgY - b1 * avgX1 - b2 * avgX2
        Console.WriteLine("a = " + a)
    End Sub




End Class
