﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.x1text = New System.Windows.Forms.TextBox()
        Me.x2text = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.aText = New System.Windows.Forms.Label()
        Me.FirstB = New System.Windows.Forms.Label()
        Me.CheckRegression = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SecondB = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'x1text
        '
        Me.x1text.Location = New System.Drawing.Point(92, 244)
        Me.x1text.Name = "x1text"
        Me.x1text.Size = New System.Drawing.Size(100, 20)
        Me.x1text.TabIndex = 0
        '
        'x2text
        '
        Me.x2text.Location = New System.Drawing.Point(257, 244)
        Me.x2text.Name = "x2text"
        Me.x2text.Size = New System.Drawing.Size(100, 20)
        Me.x2text.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(113, 225)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(266, 224)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(39, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Label2"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(107, 81)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.ScrollAlwaysVisible = True
        Me.ListBox1.Size = New System.Drawing.Size(250, 95)
        Me.ListBox1.TabIndex = 4
        '
        'aText
        '
        Me.aText.AutoSize = True
        Me.aText.Location = New System.Drawing.Point(380, 32)
        Me.aText.Name = "aText"
        Me.aText.Size = New System.Drawing.Size(14, 13)
        Me.aText.TabIndex = 5
        Me.aText.Text = "A"
        '
        'FirstB
        '
        Me.FirstB.AutoSize = True
        Me.FirstB.Location = New System.Drawing.Point(380, 61)
        Me.FirstB.Name = "FirstB"
        Me.FirstB.Size = New System.Drawing.Size(20, 13)
        Me.FirstB.TabIndex = 6
        Me.FirstB.Text = "B1"
        '
        'CheckRegression
        '
        Me.CheckRegression.Location = New System.Drawing.Point(70, 347)
        Me.CheckRegression.Name = "CheckRegression"
        Me.CheckRegression.Size = New System.Drawing.Size(122, 23)
        Me.CheckRegression.TabIndex = 7
        Me.CheckRegression.Text = "Load Regression"
        Me.CheckRegression.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(269, 347)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(125, 23)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Calculate Prediction"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(53, 32)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 9
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'SecondB
        '
        Me.SecondB.AutoSize = True
        Me.SecondB.Location = New System.Drawing.Point(380, 90)
        Me.SecondB.Name = "SecondB"
        Me.SecondB.Size = New System.Drawing.Size(20, 13)
        Me.SecondB.TabIndex = 10
        Me.SecondB.Text = "B2"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(508, 394)
        Me.Controls.Add(Me.SecondB)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.CheckRegression)
        Me.Controls.Add(Me.FirstB)
        Me.Controls.Add(Me.aText)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.x2text)
        Me.Controls.Add(Me.x1text)
        Me.Name = "Form2"
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents x1text As TextBox
    Friend WithEvents x2text As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents aText As Label
    Friend WithEvents FirstB As Label
    Friend WithEvents CheckRegression As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents SecondB As Label
End Class
