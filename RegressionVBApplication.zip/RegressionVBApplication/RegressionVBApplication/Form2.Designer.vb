﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.x1text = New System.Windows.Forms.TextBox()
        Me.x2text = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.aText = New System.Windows.Forms.Label()
        Me.FirstB = New System.Windows.Forms.Label()
        Me.CheckRegression = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SecondB = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'x1text
        '
        Me.x1text.Location = New System.Drawing.Point(123, 357)
        Me.x1text.Margin = New System.Windows.Forms.Padding(4)
        Me.x1text.Name = "x1text"
        Me.x1text.Size = New System.Drawing.Size(132, 27)
        Me.x1text.TabIndex = 0
        '
        'x2text
        '
        Me.x2text.Location = New System.Drawing.Point(343, 357)
        Me.x2text.Margin = New System.Windows.Forms.Padding(4)
        Me.x2text.Name = "x2text"
        Me.x2text.Size = New System.Drawing.Size(132, 27)
        Me.x2text.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(151, 329)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 19)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "X1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(355, 327)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 19)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "X2"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 19
        Me.ListBox1.Location = New System.Drawing.Point(143, 118)
        Me.ListBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.ScrollAlwaysVisible = True
        Me.ListBox1.Size = New System.Drawing.Size(332, 137)
        Me.ListBox1.TabIndex = 4
        '
        'aText
        '
        Me.aText.AutoSize = True
        Me.aText.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.aText.Location = New System.Drawing.Point(455, 9)
        Me.aText.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.aText.Name = "aText"
        Me.aText.Size = New System.Drawing.Size(20, 19)
        Me.aText.TabIndex = 5
        Me.aText.Text = "A"
        '
        'FirstB
        '
        Me.FirstB.AutoSize = True
        Me.FirstB.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FirstB.Location = New System.Drawing.Point(455, 33)
        Me.FirstB.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.FirstB.Name = "FirstB"
        Me.FirstB.Size = New System.Drawing.Size(28, 19)
        Me.FirstB.TabIndex = 6
        Me.FirstB.Text = "B1"
        '
        'CheckRegression
        '
        Me.CheckRegression.Location = New System.Drawing.Point(93, 507)
        Me.CheckRegression.Margin = New System.Windows.Forms.Padding(4)
        Me.CheckRegression.Name = "CheckRegression"
        Me.CheckRegression.Size = New System.Drawing.Size(163, 34)
        Me.CheckRegression.TabIndex = 7
        Me.CheckRegression.Text = "Load Regression Data"
        Me.CheckRegression.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(359, 507)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(167, 34)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "Calculate Prediction"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(16, 18)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 34)
        Me.Button2.TabIndex = 9
        Me.Button2.Text = "Back"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'SecondB
        '
        Me.SecondB.AutoSize = True
        Me.SecondB.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SecondB.Location = New System.Drawing.Point(455, 65)
        Me.SecondB.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.SecondB.Name = "SecondB"
        Me.SecondB.Size = New System.Drawing.Size(28, 19)
        Me.SecondB.TabIndex = 10
        Me.SecondB.Text = "B2"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(677, 576)
        Me.Controls.Add(Me.SecondB)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.CheckRegression)
        Me.Controls.Add(Me.FirstB)
        Me.Controls.Add(Me.aText)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.x2text)
        Me.Controls.Add(Me.x1text)
        Me.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form2"
        Me.Text = "Baldur's Gate Prediction Program"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents x1text As TextBox
    Friend WithEvents x2text As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents aText As Label
    Friend WithEvents FirstB As Label
    Friend WithEvents CheckRegression As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents SecondB As Label
End Class
