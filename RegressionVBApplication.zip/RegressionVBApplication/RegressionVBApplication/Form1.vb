﻿Imports System.Data.SqlClient

Public Class Form1

    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    Private Sub ShowButton_Click(sender As Object, e As EventArgs) Handles ShowButton.Click
        myConn = New SqlConnection("Data Source=LI-LAB-SQL;Persist Security Info=True;Password=Lalaland123!;User ID=jvetri")
        Dim players As Integer
        Dim sales As Integer
        Dim days As Integer

        ' Create command
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "EXEC SP_SelectBaldursGate3"

        'open the connection 
        myConn.Open()
        myReader = myCmd.ExecuteReader()

        ListBox1.Items.Clear()

        While myReader.Read()
            days = myReader(0).ToString
            sales = myReader(1).ToString
            players = myReader(2).ToString

            Dim counter As Integer
            counter = 1

            ListBox1.Items.Add(" " & days & " " & players & " " & sales)

            counter = counter + 1
        End While

    End Sub

    Private Sub InsertButton_Click(sender As Object, e As EventArgs) Handles InsertButton.Click
        myConn = New SqlConnection("Data Source=LI-LAB-SQL;Persist Security Info=True;Password=Lalaland123!;User ID=jvetri")


        myCmd = myConn.CreateCommand
        myCmd.CommandText = "EXEC SP_InsertBaldursGate " & CInt(TextBoxDays.Text) & "," & CInt(TextBoxSales.Text) & "," & CInt(TextBoxPlayerCount.Text)

        myConn.Open()
        myReader = myCmd.ExecuteReader()

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub FormLoad2_Click(sender As Object, e As EventArgs) Handles FormLoad2.Click
        Me.Hide()
        Form2.Show()
    End Sub
End Class
