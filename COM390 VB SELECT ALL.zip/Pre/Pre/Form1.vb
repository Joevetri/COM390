﻿Imports System.Data.SqlClient
Public Class Form1
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String


    Private Sub BaldursGate3BindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles BaldursGate3BindingNavigatorSaveItem.Click
        Me.Validate()
        Me.BaldursGate3BindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.JoeAidenProjectDataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'JoeAidenProjectDataSet.BaldursGate3' table. You can move, or remove it, as needed.
        Me.BaldursGate3TableAdapter.Fill(Me.JoeAidenProjectDataSet.BaldursGate3)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        myConn = New SqlConnection("Data Source=DESKTOP-PL4U5D2;Initial Catalog=JoeAidenProject;Integrated Security=True")
        Dim dates As Integer
        Dim sales As Integer
        Dim players As Integer
        'Create a Command object.
        myCmd = myConn.CreateCommand
        'myCmd.CommandText = "SELECT studentnumber, name from STUDENT"
        myCmd.CommandText = "EXEC SelectAllBaldursGate3"
        'Open the connection.
        myConn.Open()
        'Run the command
        myReader = myCmd.ExecuteReader()
        ' Get and output the results using a loop
        While myReader.Read()
            dates = myReader(0).ToString
            sales = myReader(1).ToString
            players = myReader(2).ToString
            ListBox1.Items.Add("Days Since Release: " & dates & " Sales by Employed: " & sales & " Player Count: " & players)
        End While
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged

    End Sub
End Class
