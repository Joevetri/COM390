﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.TextBoxDays = New System.Windows.Forms.TextBox()
        Me.TextBoxPlayerCount = New System.Windows.Forms.TextBox()
        Me.TextBoxSales = New System.Windows.Forms.TextBox()
        Me.DepLabel = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.InsertButton = New System.Windows.Forms.Button()
        Me.ShowButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FormLoad2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 19
        Me.ListBox1.Location = New System.Drawing.Point(105, 117)
        Me.ListBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.ScrollAlwaysVisible = True
        Me.ListBox1.Size = New System.Drawing.Size(461, 251)
        Me.ListBox1.TabIndex = 0
        '
        'TextBoxDays
        '
        Me.TextBoxDays.Location = New System.Drawing.Point(73, 411)
        Me.TextBoxDays.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBoxDays.Name = "TextBoxDays"
        Me.TextBoxDays.Size = New System.Drawing.Size(132, 27)
        Me.TextBoxDays.TabIndex = 1
        '
        'TextBoxPlayerCount
        '
        Me.TextBoxPlayerCount.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.TextBoxPlayerCount.Location = New System.Drawing.Point(288, 411)
        Me.TextBoxPlayerCount.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBoxPlayerCount.Name = "TextBoxPlayerCount"
        Me.TextBoxPlayerCount.Size = New System.Drawing.Size(132, 27)
        Me.TextBoxPlayerCount.TabIndex = 2
        '
        'TextBoxSales
        '
        Me.TextBoxSales.Location = New System.Drawing.Point(480, 411)
        Me.TextBoxSales.Margin = New System.Windows.Forms.Padding(4)
        Me.TextBoxSales.Name = "TextBoxSales"
        Me.TextBoxSales.Size = New System.Drawing.Size(132, 27)
        Me.TextBoxSales.TabIndex = 3
        '
        'DepLabel
        '
        Me.DepLabel.AutoSize = True
        Me.DepLabel.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DepLabel.Location = New System.Drawing.Point(69, 388)
        Me.DepLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.DepLabel.Name = "DepLabel"
        Me.DepLabel.Size = New System.Drawing.Size(166, 19)
        Me.DepLabel.TabIndex = 4
        Me.DepLabel.Text = "DaysAfterRelease - X2"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(284, 448)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(0, 19)
        Me.Label2.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(476, 388)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 19)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "PlayerCount - Y"
        '
        'InsertButton
        '
        Me.InsertButton.Location = New System.Drawing.Point(335, 520)
        Me.InsertButton.Margin = New System.Windows.Forms.Padding(4)
        Me.InsertButton.Name = "InsertButton"
        Me.InsertButton.Size = New System.Drawing.Size(111, 34)
        Me.InsertButton.TabIndex = 7
        Me.InsertButton.Text = "InsertButton"
        Me.InsertButton.UseVisualStyleBackColor = True
        '
        'ShowButton
        '
        Me.ShowButton.Location = New System.Drawing.Point(232, 520)
        Me.ShowButton.Margin = New System.Windows.Forms.Padding(4)
        Me.ShowButton.Name = "ShowButton"
        Me.ShowButton.Size = New System.Drawing.Size(100, 34)
        Me.ShowButton.TabIndex = 8
        Me.ShowButton.Text = "Show Table"
        Me.ShowButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(288, 388)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 19)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Sales - X1"
        '
        'FormLoad2
        '
        Me.FormLoad2.Location = New System.Drawing.Point(591, 3)
        Me.FormLoad2.Margin = New System.Windows.Forms.Padding(4)
        Me.FormLoad2.Name = "FormLoad2"
        Me.FormLoad2.Size = New System.Drawing.Size(100, 34)
        Me.FormLoad2.TabIndex = 10
        Me.FormLoad2.Text = "Test Data"
        Me.FormLoad2.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(693, 555)
        Me.Controls.Add(Me.FormLoad2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ShowButton)
        Me.Controls.Add(Me.InsertButton)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.DepLabel)
        Me.Controls.Add(Me.TextBoxSales)
        Me.Controls.Add(Me.TextBoxPlayerCount)
        Me.Controls.Add(Me.TextBoxDays)
        Me.Controls.Add(Me.ListBox1)
        Me.Font = New System.Drawing.Font("Microsoft Tai Le", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.Text = "Baldur's Gate Regression Program"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents TextBoxDays As TextBox
    Friend WithEvents TextBoxPlayerCount As TextBox
    Friend WithEvents TextBoxSales As TextBox
    Friend WithEvents DepLabel As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents InsertButton As Button
    Friend WithEvents ShowButton As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents FormLoad2 As Button
End Class
