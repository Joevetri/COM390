﻿Imports System.Data.SqlClient


Public Class Form2


    Dim sumy_2, sumx1_2, sumx2_2 As Double
    Dim sumx1y, sumx2y, sumx1x2 As Double
    Dim a, b1, b2 As Double

    Dim CounterGlobal As Integer

    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub CheckRegression_Click(sender As Object, e As EventArgs) Handles CheckRegression.Click

        Try
            Dim avgY, avgX1, avgX2 As Double
            Dim sumY, sumX1, sumX2 As Double
            Dim sumSQY, sumSQX1, sumSQX2 As Double
            Dim sumYX1, sumYX2, sumX1X2 As Double

            'sql connection
            myConn = New SqlConnection("Data Source=LI-LAB-SQL;Persist Security Info=True;Password=Lalaland123!;User ID=jvetri")
            Dim players As Integer
            Dim sales As Integer
            Dim days As Integer

            Dim Y(100) As Double
            Dim X1(100) As Double
            Dim X2(100) As Double

            ' Create command
            myCmd = myConn.CreateCommand
            myCmd.CommandText = "EXEC SP_SelectBaldursGate3"

            'open the connection 
            myConn.Open()
            myReader = myCmd.ExecuteReader()

            ListBox1.Items.Clear()

            Dim counter As Integer
            counter = 0

            While myReader.Read()
                days = myReader(0).ToString
                sales = myReader(1).ToString
                players = myReader(2).ToString


                'Reader gets variables for correct positions in columns, puts them in cooresponding arrays. 


                X2(counter) = days
                Y(counter) = players
                X1(counter) = sales

                counter = counter + 1




            End While

            'global variable to hold array size
            CounterGlobal = counter


            Dim N = (CounterGlobal)

            sumY = CalcSum(Y)
            avgY = CalcMean(sumY, Y.Length)

            sumX1 = CalcSum(X1)
            avgX1 = CalcMean(sumX1, X1.Length)

            sumX2 = CalcSum(X2)
            avgX2 = CalcMean(sumX2, X2.Length)

            Console.WriteLine("Sum Y = " & sumY & "  avgY = " & avgY)
            Console.WriteLine("SumX1 = " & sumX1 & "  avgX1 = " & avgX1)
            Console.WriteLine("SumX2 = " & sumX2 & "  avgX2 = " & avgX2)

            sumSQY = CalcSumOfSquares(Y)
            sumSQX1 = CalcSumOfSquares(X1)
            sumSQX2 = CalcSumOfSquares(X2)

            Console.WriteLine("Y SQ =" & sumSQY & "  X1 SQ = " & sumSQX1 & " X2 SQ = " & sumSQX2)

            sumYX1 = CalcSumOfVar(Y, X1)
            sumYX2 = CalcSumOfVar(Y, X2)
            sumX1X2 = CalcSumOfVar(X1, X2)

            Console.WriteLine("YX1 = " & sumYX1 & " YX2 = " & sumYX2 & " X1X2
        " & sumX1X2)

            sumy_2 = sumSQY - (Math.Pow(sumY, 2) / N)
            Console.WriteLine(" " & sumy_2)

            Dim sumx1_2 = sumSQX1 - (Math.Pow(sumX1, 2) / N)

            Console.WriteLine(" " & sumx1_2)
            Dim sumx2_2 = sumSQX2 - (Math.Pow(sumX2, 2) / N)
            Console.WriteLine(" " & sumx2_2)
            Dim sumx1y = sumYX1 - ((sumX1 * sumY) / N)
            Console.WriteLine(" " & sumx1y)
            Dim sumx2y = sumYX2 - ((sumX2 * sumY) / N)
            Console.WriteLine(" " & sumx2y)
            sumX1X2 = sumX1X2 - ((sumX1 * sumX2) / N)
            Console.WriteLine(" " & sumX1X2)
            Dim b1 = (sumx2_2 * sumx1y - sumX1X2 * sumx2y) / (sumx1_2 * sumx2_2 -
                sumX1X2 * sumX1X2)
            Console.WriteLine("b1 = " & b1)
            Dim b2 = (sumx1_2 * sumx2y - sumX1X2 * sumx1y) / (sumx1_2 * sumx2_2 -
                sumX1X2 * sumX1X2)
            Console.WriteLine("b2 = " & b2)
            Dim a = avgY - b1 * avgX1 - b2 * avgX2
            Console.WriteLine("a = " & a)

            'label that shows a , b1, b2
            aText.Text = a
            FirstB.Text = b1
            SecondB.Text = b2

        Catch ex As Exception
            MsgBox("Error")
        End Try

    End Sub


    Public Function CalcMean(sum As Double, N As Double) As Double
        Dim avg As Double
        avg = 0
        avg = sum / N
        Return avg


    End Function

    Public Function CalcSum(Array As Double())
        Dim sum As Double
        sum = 0
        For i As Integer = 0 To CounterGlobal - 1
            sum = sum + Array(i)
        Next
        Return sum
    End Function

    Public Function CalcSumOfSquares(Array As Double())

        Dim sum As Double
        sum = 0

        For i As Integer = 0 To CounterGlobal - 1
            sum = sum + (Array(i) ^ 2)
        Next

        Return sum

    End Function

    Public Function CalcSumOfVar(Array1 As Double(), Array2 As Double())
        Dim sum As Double

        sum = 0

        For i As Integer = 0 To CounterGlobal - 1
            sum = sum + (Array1(i) * Array2(i))
        Next
        Return sum
    End Function


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        Try

            Dim x1 = x1text.Text
            Dim x2 = x2text.Text

            'prediction equation
            Dim y = aText.Text + FirstB.Text * (x1) + SecondB.Text * (x2)

            'add predection y to listbox
            ListBox1.Items.Add(y)


        Catch ex As Exception
            MsgBox("Error")
        End Try

    End Sub
End Class