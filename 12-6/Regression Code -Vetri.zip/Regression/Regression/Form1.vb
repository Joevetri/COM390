﻿Public Class Form1

    'Joseph Vetri , Aiden Walsh - Regression Code Fixed/Ran against Java code

    Dim sumy_2, sumx1_2, sumx2_2 As Double
    Dim sumx1y, sumx2y, sumx1x2 As Double
    Dim a, b1, b2 As Double

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim avgY, avgX1, avgX2 As Double
        Dim sumY, sumX1, sumX2 As Double
        Dim sumSQY, sumSQX1, sumSQX2 As Double
        Dim sumYX1, sumYX2, sumX1X2 As Double

        Dim Y = New Double() {591792, 709835, 814466, 707445, 665960, 646696, 634578,
            653212, 789886, 876343, 688724, 667496, 629900, 616718, 622394, 729605, 813254, 631783, 566928, 540894}
        Dim X1 = New Double() {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19}
        Dim X2 = New Double() {439226, 272432, 252332, 223443, 254615, 243516, 242152, 235153, 301253, 320371, 201821, 203820, 192839,
        179382, 189292, 182192, 137291, 109382, 103849, 104374}



        Dim N = (Y.Length)

        sumY = CalcSum(Y)
        avgY = CalcMean(sumY, Y.Length)

        sumX1 = CalcSum(X1)
        avgX1 = CalcMean(sumX1, X1.Length)

        sumX2 = CalcSum(X2)
        avgX2 = CalcMean(sumX2, X2.Length)

        Console.WriteLine("Sum Y = " & sumY & "  avgY = " & avgY)
        Console.WriteLine("SumX1 = " & sumX1 & "  avgX1 = " & avgX1)
        Console.WriteLine("SumX2 = " & sumX2 & "  avgX2 = " & avgX2)

        sumSQY = CalcSumOfSquares(Y)
        sumSQX1 = CalcSumOfSquares(X1)
        sumSQX2 = CalcSumOfSquares(X2)

        Console.WriteLine("Y SQ =" & sumSQY & "  X1 SQ = " & sumSQX1 & " X2 SQ = " & sumSQX2)

        sumYX1 = CalcSumOfVar(Y, X1)
        sumYX2 = CalcSumOfVar(Y, X2)
        sumX1X2 = CalcSumOfVar(X1, X2)

        Console.WriteLine("YX1 = " & sumYX1 & " YX2 = " & sumYX2 & " X1X2
        " & sumX1X2)

        sumy_2 = sumSQY - (Math.Pow(sumY, 2) / N)
        Console.WriteLine(" " & sumy_2)

        Dim sumx1_2 = sumSQX1 - (Math.Pow(sumX1, 2) / N)

        Console.WriteLine(" " & sumx1_2)
        Dim sumx2_2 = sumSQX2 - (Math.Pow(sumX2, 2) / N)
        Console.WriteLine(" " & sumx2_2)
        Dim sumx1y = sumYX1 - ((sumX1 * sumY) / N)
        Console.WriteLine(" " & sumx1y)
        Dim sumx2y = sumYX2 - ((sumX2 * sumY) / N)
        Console.WriteLine(" " & sumx2y)
        sumX1X2 = sumX1X2 - ((sumX1 * sumX2) / N)
        Console.WriteLine(" " & sumX1X2)
        Dim b1 = (sumx2_2 * sumx1y - sumX1X2 * sumx2y) / (sumx1_2 * sumx2_2 -
        sumX1X2 * sumX1X2)
        Console.WriteLine("b1 = " & b1)
        Dim b2 = (sumx1_2 * sumx2y - sumX1X2 * sumx1y) / (sumx1_2 * sumx2_2 -
        sumX1X2 * sumX1X2)
        Console.WriteLine("b2 = " & b2)
        Dim a = avgY - b1 * avgX1 - b2 * avgX2
        Console.WriteLine("a = " & a)
    End Sub

    Public Function CalcMean(sum As Double, N As Double) As Double
        Dim avg As Double
        avg = 0
        avg = sum / N
        Return avg


    End Function

    Public Function CalcSum(Array As Double())
        Dim sum As Double
        sum = 0
        For i As Integer = 0 To Array.Length - 1
            sum = sum + Array(i)
        Next
        Return sum
    End Function

    Public Function CalcSumOfSquares(Array As Double())

        Dim sum As Double
        sum = 0

        For i As Integer = 0 To Array.Length - 1
            sum = sum + (Array(i) ^ 2)
        Next

        Return sum

    End Function

    Public Function CalcSumOfVar(Array1 As Double(), Array2 As Double())
        Dim sum As Double

        sum = 0

        For i As Integer = 0 To Array1.Length - 1
            sum = sum + (Array1(i) * Array2(i))
        Next
        Return sum
    End Function


End Class
