﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.txtname = New System.Windows.Forms.TextBox()
        Me.textnum = New System.Windows.Forms.TextBox()
        Me.textclass = New System.Windows.Forms.TextBox()
        Me.textmajor = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnInsert = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(28, 12)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.ScrollAlwaysVisible = True
        Me.ListBox1.Size = New System.Drawing.Size(614, 82)
        Me.ListBox1.TabIndex = 0
        '
        'btnShow
        '
        Me.btnShow.Location = New System.Drawing.Point(28, 222)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(158, 52)
        Me.btnShow.TabIndex = 1
        Me.btnShow.Text = "SHOW STUDENTS"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(37, 174)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(100, 20)
        Me.txtname.TabIndex = 2
        '
        'textnum
        '
        Me.textnum.Location = New System.Drawing.Point(143, 174)
        Me.textnum.Name = "textnum"
        Me.textnum.Size = New System.Drawing.Size(100, 20)
        Me.textnum.TabIndex = 3
        '
        'textclass
        '
        Me.textclass.Location = New System.Drawing.Point(249, 174)
        Me.textclass.Name = "textclass"
        Me.textclass.Size = New System.Drawing.Size(100, 20)
        Me.textclass.TabIndex = 4
        '
        'textmajor
        '
        Me.textmajor.Location = New System.Drawing.Point(355, 174)
        Me.textmajor.Name = "textmajor"
        Me.textmajor.Size = New System.Drawing.Size(100, 20)
        Me.textmajor.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label1.Location = New System.Drawing.Point(34, 158)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Name"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label2.Location = New System.Drawing.Point(140, 158)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "StudentNum"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label3.Location = New System.Drawing.Point(246, 158)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Class"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.Label4.Location = New System.Drawing.Point(352, 158)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 13)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Major"
        '
        'btnInsert
        '
        Me.btnInsert.Location = New System.Drawing.Point(215, 222)
        Me.btnInsert.Name = "btnInsert"
        Me.btnInsert.Size = New System.Drawing.Size(161, 52)
        Me.btnInsert.TabIndex = 10
        Me.btnInsert.Text = "INSERT STUDENTS"
        Me.btnInsert.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Coral
        Me.BackgroundImage = Global.StudentTableApplication.My.Resources.Resources.opener0403acadia
        Me.ClientSize = New System.Drawing.Size(681, 313)
        Me.Controls.Add(Me.btnInsert)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.textmajor)
        Me.Controls.Add(Me.textclass)
        Me.Controls.Add(Me.textnum)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.ListBox1)
        Me.ForeColor = System.Drawing.Color.Coral
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents btnShow As Button
    Friend WithEvents txtname As TextBox
    Friend WithEvents textnum As TextBox
    Friend WithEvents textclass As TextBox
    Friend WithEvents textmajor As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents btnInsert As Button
End Class
