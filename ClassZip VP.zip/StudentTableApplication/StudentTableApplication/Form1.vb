﻿Imports System.Data.SqlClient

Public Class Form1

    Inherits System.Windows.Forms.Form
    'CREATE ADO.NET objects
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles btnShow.Click
        myConn = New SqlConnection("Data Source=LI-LAB-SQL;Persist Security Info=True;Password=Lalaland123!;User ID=jvetri")
        Dim name As String
        Dim studentNum As String
        Dim class1 As Integer
        Dim major As String
        ' Create command
        myCmd = myConn.CreateCommand
        myCmd.CommandText = "EXEC SP_GETSTUDENTJOE"

        'open the connection 
        myConn.Open()
        myReader = myCmd.ExecuteReader()

        ListBox1.Items.Clear()

        While myReader.Read()
            name = myReader(0).ToString
            studentNum = myReader(1).ToString
            class1 = myReader(2).ToString
            major = myReader(3).ToString

            ListBox1.Items.Add(" " & name & " " & studentNum & " " & class1 & " " & major)


        End While
    End Sub


    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        myConn = New SqlConnection("Data Source=LI-LAB-SQL;Persist Security Info=True;Password=Lalaland123!;User ID=jvetri")
        Dim name As String
        Dim studentNum As String
        Dim class1 As Integer
        Dim major As String

        myCmd = myConn.CreateCommand
        myCmd.CommandText = "EXEC SP_InsertStudentJV '" & txtname.Text & "'," & CInt(textnum.Text) & "," & CInt(textclass.Text) & ",'" & textmajor.Text & "'"

        myConn.Open()
        myReader = myCmd.ExecuteReader()

    End Sub
End Class
