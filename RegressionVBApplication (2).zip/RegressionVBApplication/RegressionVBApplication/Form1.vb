﻿Imports System.Data.SqlClient

Public Class Form1
    'sql imports
    Private myConn As SqlConnection
    Private myCmd As SqlCommand
    Private myReader As SqlDataReader
    Private results As String

    Private Sub ShowButton_Click(sender As Object, e As EventArgs) Handles ShowButton.Click

        Try
            'sqlconnection object
            myConn = New SqlConnection("Data Source=LI-LAB-SQL;Persist Security Info=True;Password=Lalaland123!;User ID=jvetri")
            Dim players As Integer
            Dim sales As Integer
            Dim days As Integer

            ' Create command
            myCmd = myConn.CreateCommand
            myCmd.CommandText = "EXEC SP_SelectBaldursGate3"

            'open the connection 
            myConn.Open()
            myReader = myCmd.ExecuteReader()

            'clear listbox for updating
            ListBox1.Items.Clear()

            'ExectureReader while loop that reads through the data and assigns it to variables. Variables are added to listbox. Loop continues.
            ListBox1.Items.Add(" DAYS:    PLAYERS:    SALES: ")
            'ExectureReader while loop that reads through the data and assigns it to variables. Variables are added to listbox. Loop continues.
            While myReader.Read()
                days = myReader(0).ToString
                sales = myReader(1).ToString
                players = myReader(2).ToString
                Dim counter As Integer
                counter = 1
                ListBox1.Items.Add(" " & days & "           " & players & "           " & sales)
                counter = counter + 1
            End While

        Catch ex As Exception
            MsgBox("Error")
        End Try

    End Sub

    Private Sub InsertButton_Click(sender As Object, e As EventArgs) Handles InsertButton.Click

        Try
            'SqlConnection
            myConn = New SqlConnection("Data Source=LI-LAB-SQL;Persist Security Info=True;Password=Lalaland123!;User ID=jvetri")

            'Exectues a Stored procedure that takes values from textbox's and inserts to the table
            myCmd = myConn.CreateCommand
            myCmd.CommandText = "EXEC SP_InsertBaldursGate " & CInt(TextBoxDays.Text) & "," & CInt(TextBoxSales.Text) & "," & CInt(TextBoxPlayerCount.Text)

            myConn.Open()
            myReader = myCmd.ExecuteReader()


        Catch ex As Exception
            MsgBox("Error")
        End Try

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub FormLoad2_Click(sender As Object, e As EventArgs) Handles FormLoad2.Click
        'hide this form, show next form
        Me.Hide()
        Form2.Show()
    End Sub
End Class
